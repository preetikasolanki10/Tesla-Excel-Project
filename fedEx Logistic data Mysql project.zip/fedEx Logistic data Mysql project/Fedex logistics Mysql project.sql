Create database fedex_logistics;
use fedex_logistics;

show tables;

select * from fedex_orders;
select * from delivery_agents;
select * from fedex_routes;
select * from fedex_shipments;
select * from fedex_warehouses;

-- Task 1
-- Check Duplicate Order_ID

SELECT Order_ID, count(*) AS duplicate_count
FROM fedex_orders
GROUP BY Order_ID
HAVING COUNT(*) > 1;

-- Check Duplicate Shipment_ID

SELECT Shipment_ID, COUNT(*) AS duplicate_count
FROM fedex_shipments
GROUP BY Shipment_ID
HAVING COUNT(*) > 1;

-- Find NULL Delay_Hours

SELECT *
FROM fedex_shipments
WHERE Delay_Hours IS NULL;

-- Replace NULL Delay_Hours with Route Average

UPDATE fedex_shipments s
JOIN (
    SELECT Route_ID,
           AVG(Delay_Hours) AS avg_delay
    FROM fedex_shipments
    WHERE Delay_Hours IS NOT NULL
    GROUP BY Route_ID
) r
ON s.Route_ID = r.Route_ID
SET s.Delay_Hours = r.avg_delay
WHERE s.Delay_Hours IS NULL;

-- Check Invalid Dates

SELECT Shipment_ID,
       Pickup_Date,
       Delivery_Date
FROM fedex_shipments
WHERE Delivery_Date < Pickup_Date;

-- Validate Orders → Routes

SELECT o.*
FROM fedex_orders o
LEFT JOIN fedex_routes r
ON o.Route_ID = r.Route_ID
WHERE r.Route_ID IS NULL;

-- Validate Orders → Warehouses

SELECT o.*
FROM fedex_orders o
LEFT JOIN fedex_warehouses w
ON o.Warehouse_ID = w.Warehouse_ID
WHERE w.Warehouse_ID IS NULL;

-- Validate Shipments → Orders

SELECT s.*
FROM fedex_shipments s
LEFT JOIN fedex_orders o
ON s.Order_ID = o.Order_ID
WHERE o.Order_ID IS NULL;

-- Validate Shipments → Routes

SELECT s.*
FROM fedex_shipments s
LEFT JOIN fedex_routes r
ON s.Route_ID = r.Route_ID
WHERE r.Route_ID IS NULL;

-- Validate Shipments → Warehouses

SELECT s.*
FROM fedex_shipments s
LEFT JOIN fedex_warehouses w
ON s.Warehouse_ID = w.Warehouse_ID
WHERE w.Warehouse_ID IS NULL;

-- Validate Shipments → Delivery Agents

SELECT s.*
FROM fedex_shipments s
LEFT JOIN delivery_agents a
ON s.Agent_ID = a.Agent_ID
WHERE a.Agent_ID IS NULL;

-- Task 2 Delivery delay analysis

-- Calculate delivery delay for each shipment

SELECT 
    Shipment_ID,
    Order_ID,
    Route_ID,
    Warehouse_ID,
    Pickup_Date,
    Delivery_Date,
    TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date) AS calculated_delay_hours,
    Delay_Hours
FROM fedex_shipments;

-- Top 10 delayed routes

SELECT 
    s.Route_ID,
    r.Source_City,
    r.Source_Country,
    r.Destination_City,
    r.Destination_Country,
    ROUND(AVG(s.Delay_Hours), 2) AS avg_delay_hours,
    COUNT(*) AS total_shipments
FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID
GROUP BY 
    s.Route_ID,
    r.Source_City,
    r.Source_Country,
    r.Destination_City,
    r.Destination_Country
ORDER BY avg_delay_hours DESC
LIMIT 10;

-- Rank shipments by delay inside each warehouse

SELECT 
    Shipment_ID,
    Warehouse_ID,
    Route_ID,
    Delay_Hours,
    RANK() OVER (
        PARTITION BY Warehouse_ID 
        ORDER BY Delay_Hours DESC
    ) AS delay_rank
FROM fedex_shipments;

-- Average delay by delivery type

SELECT 
    o.Delivery_Type,
    ROUND(AVG(s.Delay_Hours), 2) AS avg_delay_hours,
    COUNT(*) AS total_shipments
FROM fedex_shipments s
JOIN fedex_orders o
ON s.Order_ID = o.Order_ID
GROUP BY o.Delivery_Type
ORDER BY avg_delay_hours DESC;

-- Task 3 Route optimization Insights

-- Average Transit Time Across Shipments

SELECT 
    s.Route_ID,
    r.Source_City,
    r.Destination_City,
    ROUND(
        AVG(TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)), 
        2
    ) AS avg_transit_time_hours
FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID
GROUP BY 
    s.Route_ID,
    r.Source_City,
    r.Destination_City
ORDER BY avg_transit_time_hours DESC;

-- Average delay per route

SELECT 
    s.Route_ID,
    r.Source_City,
    r.Destination_City,
    ROUND(AVG(s.Delay_Hours), 2) AS avg_delay_hours
FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID
GROUP BY 
    s.Route_ID,
    r.Source_City,
    r.Destination_City
ORDER BY avg_delay_hours DESC;

-- Distance-to-Time Efficiency Ratio
-- Distance_KM / Avg_Transit_Time_Hours

SELECT 
    Route_ID,
    Source_City,
    Destination_City,
    Distance_KM,
    Avg_Transit_Time_Hours,
    ROUND(
        Distance_KM / Avg_Transit_Time_Hours,
        2
    ) AS efficiency_ratio
FROM fedex_routes
ORDER BY efficiency_ratio ASC;
 -- Higher ratio = better route efficiency.
 
 -- Worst 3 Routes by Efficiency
 
 SELECT 
    Route_ID,
    Source_City,
    Destination_City,
    Distance_KM,
    Avg_Transit_Time_Hours,
    ROUND(
        Distance_KM / Avg_Transit_Time_Hours,
        2
    ) AS efficiency_ratio
FROM fedex_routes
ORDER BY efficiency_ratio ASC
LIMIT 3;

-- Routes with >20% Delayed Shipments


-- Expected transit time compared against actual shipment time.

SELECT 
    s.Route_ID,
    r.Source_City,
    r.Destination_City,
    COUNT(*) AS total_shipments,

    SUM(
        CASE 
            WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
                 > r.Avg_Transit_Time_Hours
            THEN 1
            ELSE 0
        END
    ) AS delayed_shipments,

    ROUND(
        (
            SUM(
                CASE 
                    WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
                         > r.Avg_Transit_Time_Hours
                    THEN 1
                    ELSE 0
                END
            ) * 100.0
        ) / COUNT(*),
        2
    ) AS delayed_percentage

FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID

GROUP BY 
    s.Route_ID,
    r.Source_City,
    r.Destination_City

HAVING delayed_percentage > 20

ORDER BY delayed_percentage DESC;

-- Optimization Recommendation Query
-- Identify highly delayed + low efficiency routes.

SELECT 
    s.Route_ID,
    r.Source_City,
    r.Destination_City,

    ROUND(AVG(s.Delay_Hours), 2) AS avg_delay,

    ROUND(
        r.Distance_KM / r.Avg_Transit_Time_Hours,
        2
    ) AS efficiency_ratio

FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID

GROUP BY 
    s.Route_ID,
    r.Source_City,
    r.Destination_City,
    r.Distance_KM,
    r.Avg_Transit_Time_Hours

ORDER BY 
    avg_delay DESC,
    efficiency_ratio ASC;
    
    -- Task 4
    -- Top 3 Warehouses with Highest Average Delay
    
    SELECT 
    s.Warehouse_ID,
    w.City,
    w.Country,
    ROUND(AVG(s.Delay_Hours), 2) AS avg_delay_hours
FROM fedex_shipments s
JOIN fedex_warehouses w
ON s.Warehouse_ID = w.Warehouse_ID
GROUP BY 
    s.Warehouse_ID,
    w.City,
    w.Country
ORDER BY avg_delay_hours DESC
LIMIT 3;

-- Total Shipments vs Delayed Shipments per Warehouse

SELECT 
    s.Warehouse_ID,
    w.City,
    COUNT(*) AS total_shipments,

    SUM(
        CASE
            WHEN s.Delay_Hours > 0 THEN 1
            ELSE 0
        END
    ) AS delayed_shipments

FROM fedex_shipments s
JOIN fedex_warehouses w
ON s.Warehouse_ID = w.Warehouse_ID

GROUP BY
    s.Warehouse_ID,
    w.City

ORDER BY delayed_shipments DESC;

-- Warehouses with Average Delay Above Global Average (Using CTE)

WITH warehouse_delay AS (
    SELECT
        Warehouse_ID,
        AVG(Delay_Hours) AS avg_delay
    FROM fedex_shipments
    GROUP BY Warehouse_ID
),

global_delay AS (
    SELECT AVG(Delay_Hours) AS global_avg_delay
    FROM fedex_shipments
)

SELECT
    wd.Warehouse_ID,
    ROUND(wd.avg_delay,2) AS warehouse_avg_delay,
    ROUND(gd.global_avg_delay,2) AS global_avg_delay
FROM warehouse_delay wd
CROSS JOIN global_delay gd
WHERE wd.avg_delay > gd.global_avg_delay
ORDER BY wd.avg_delay DESC;

-- Rank Warehouses by On-Time Delivery Percentage

SELECT
    s.Warehouse_ID,
    w.City,

    COUNT(*) AS total_shipments,

    SUM(
        CASE
            WHEN s.Delay_Hours = 0 THEN 1
            ELSE 0
        END
    ) AS on_time_shipments,

    ROUND(
        SUM(
            CASE
                WHEN s.Delay_Hours = 0 THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS on_time_percentage,

    RANK() OVER (
        ORDER BY
        ROUND(
            SUM(
                CASE
                    WHEN s.Delay_Hours = 0 THEN 1
                    ELSE 0
                END
            ) * 100.0 / COUNT(*),
            2
        ) DESC
    ) AS warehouse_rank

FROM fedex_shipments s
JOIN fedex_warehouses w
ON s.Warehouse_ID = w.Warehouse_ID

GROUP BY
    s.Warehouse_ID,
    w.City;
    
    -- Task 5 — Delivery Agent Performance
    
   -- 1. Rank Delivery Agents (per Route) by On-Time Delivery %
   
   SELECT
    s.Route_ID,
    a.Agent_ID,
    a.Agent_Name,

    COUNT(*) AS total_shipments,

    SUM(
        CASE
            WHEN s.Delay_Hours = 0 THEN 1
            ELSE 0
        END
    ) AS on_time_shipments,

    ROUND(
        SUM(
            CASE
                WHEN s.Delay_Hours = 0 THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS on_time_percentage,

    RANK() OVER (
        PARTITION BY s.Route_ID
        ORDER BY
        ROUND(
            SUM(
                CASE
                    WHEN s.Delay_Hours = 0 THEN 1
                    ELSE 0
                END
            ) * 100.0 / COUNT(*),
            2
        ) DESC
    ) AS agent_rank

FROM fedex_shipments s
JOIN delivery_agents a
ON s.Agent_ID = a.Agent_ID

GROUP BY
    s.Route_ID,
    a.Agent_ID,
    a.Agent_Name;
    
    -- 2. Agents with On-Time % Below 85%
    
    SELECT
    a.Agent_ID,
    a.Agent_Name,

    ROUND(
        SUM(
            CASE
                WHEN s.Delay_Hours = 0 THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS on_time_percentage

FROM fedex_shipments s
JOIN delivery_agents a
ON s.Agent_ID = a.Agent_ID

GROUP BY
    a.Agent_ID,
    a.Agent_Name

HAVING on_time_percentage < 85
ORDER BY on_time_percentage;

-- 3. Compare Top 5 vs Bottom 5 Agents (Rating & Experience)

WITH agent_performance AS (
    SELECT
        a.Agent_ID,
        a.Agent_Name,
        a.Avg_Rating,
        a.Experience_Years,

        ROUND(
            SUM(
                CASE
                    WHEN s.Delay_Hours = 0 THEN 1
                    ELSE 0
                END
            ) * 100.0 / COUNT(*),
            2
        ) AS on_time_percentage

    FROM delivery_agents a
    JOIN fedex_shipments s
    ON a.Agent_ID = s.Agent_ID

    GROUP BY
        a.Agent_ID,
        a.Agent_Name,
        a.Avg_Rating,
        a.Experience_Years
),

ranked_agents AS (
    SELECT *,
           ROW_NUMBER() OVER (ORDER BY on_time_percentage DESC) AS top_rank,
           ROW_NUMBER() OVER (ORDER BY on_time_percentage ASC) AS bottom_rank
    FROM agent_performance
)

SELECT
    'Top 5 Agents' AS category,
    ROUND(AVG(Avg_Rating),2) AS avg_rating,
    ROUND(AVG(Experience_Years),2) AS avg_experience
FROM ranked_agents
WHERE top_rank <= 5

UNION ALL

SELECT
    'Bottom 5 Agents',
    ROUND(AVG(Avg_Rating),2),
    ROUND(AVG(Experience_Years),2)
FROM ranked_agents
WHERE bottom_rank <= 5;

-- 4. Lowest Performing Agents

SELECT
    a.Agent_ID,
    a.Agent_Name,
    a.Experience_Years,
    a.Avg_Rating,

    ROUND(
        SUM(
            CASE
                WHEN s.Delay_Hours = 0 THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS on_time_percentage

FROM delivery_agents a
JOIN fedex_shipments s
ON a.Agent_ID = s.Agent_ID

GROUP BY
    a.Agent_ID,
    a.Agent_Name,
    a.Experience_Years,
    a.Avg_Rating

ORDER BY on_time_percentage ASC
LIMIT 5;

-- Task 6 — Shipment Tracking Analytics

--- 1. Latest Status and Delivery Date for Each Shipment

SELECT
    Shipment_ID,
    Order_ID,
    Delivery_Status,
    Delivery_Date
FROM fedex_shipments
ORDER BY Delivery_Date DESC;

-- 2. Routes Where Majority of Shipments Are In Transit or Returned

SELECT
    Route_ID,
    COUNT(*) AS total_shipments,

    SUM(
        CASE
            WHEN Delivery_Status IN ('In Transit','Returned')
            THEN 1
            ELSE 0
        END
    ) AS problem_shipments,

    ROUND(
        SUM(
            CASE
                WHEN Delivery_Status IN ('In Transit','Returned')
                THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS problem_percentage

FROM fedex_shipments

GROUP BY Route_ID

HAVING problem_percentage > 50

ORDER BY problem_percentage DESC;

-- 3. Most Frequent Delay Reasons

SELECT
    Delivery_Feedback,
    COUNT(*) AS frequency
FROM fedex_shipments
GROUP BY Delivery_Feedback
ORDER BY frequency DESC;

-- 4. Orders with Exceptionally High Delay (>120 Hours)

SELECT
    Shipment_ID,
    Order_ID,
    Route_ID,
    Warehouse_ID,
    Delay_Hours,
    Delivery_Status
FROM fedex_shipments
WHERE Delay_Hours > 120
ORDER BY Delay_Hours DESC;

-- Additional Insight Query

SELECT
    Route_ID,
    COUNT(*) AS high_delay_shipments,
    ROUND(AVG(Delay_Hours),2) AS avg_delay
FROM fedex_shipments
WHERE Delay_Hours > 120
GROUP BY Route_ID
ORDER BY high_delay_shipments DESC;

-- Task 7 — Advanced KPI Reporting

-- 1. Average Delivery Delay per Source Country

SELECT
    r.Source_Country,
    ROUND(AVG(s.Delay_Hours),2) AS avg_delivery_delay
FROM fedex_shipments s
JOIN fedex_routes r
ON s.Route_ID = r.Route_ID
GROUP BY r.Source_Country
ORDER BY avg_delivery_delay DESC;

-- 2. On-Time Delivery Percentage
-- On-Time Delivery %=Total DeliveriesTotal On-Time Deliveries​×100

SELECT
    COUNT(*) AS total_deliveries,

    SUM(
        CASE
            WHEN Delay_Hours = 0 THEN 1
            ELSE 0
        END
    ) AS on_time_deliveries,

    ROUND(
        SUM(
            CASE
                WHEN Delay_Hours = 0 THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS on_time_delivery_percentage

FROM fedex_shipments;

-- 3. Average Delay per Route_ID

SELECT
    Route_ID,
    ROUND(AVG(Delay_Hours),2) AS avg_delay_hours
FROM fedex_shipments
GROUP BY Route_ID
ORDER BY avg_delay_hours DESC;

-- 4. Warehouse Utilization %

-- Warehouse Utilization %=Capacity per DayShipments Handled​×100

SELECT
    w.Warehouse_ID,
    w.City,
    w.Capacity_per_day,

    COUNT(s.Shipment_ID) AS shipments_handled,

    ROUND(
        COUNT(s.Shipment_ID) * 100.0 /
        w.Capacity_per_day,
        2
    ) AS utilization_percentage

FROM fedex_warehouses w
LEFT JOIN fedex_shipments s
ON w.Warehouse_ID = s.Warehouse_ID

GROUP BY
    w.Warehouse_ID,
    w.City,
    w.Capacity_per_day
ORDER BY utilization_percentage DESC;

-- 5. KPI Summary Table

SELECT
    ROUND(AVG(Delay_Hours),2) AS overall_avg_delay,

    ROUND(
        SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END)
        *100.0/COUNT(*),
        2
    ) AS on_time_delivery_percentage,

    COUNT(*) AS total_shipments

FROM fedex_shipments;
